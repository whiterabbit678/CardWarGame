package com.example.cardgame;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

public class GameActivity extends AppCompatActivity {
    private List<TheCard> middledeck, carddeck1, carddeck2;
    private TextView textviewrounds, textviewforrounds;
    private ImageView cardimageforplayer1, cardimageforplayer2, cardimagefordeck;
    private Button buttonforcarddistribute, buttonfornextround;
    private int player1Score = 0, player2Score = 0, round = 1;

    private final String[] suits = {"hearts", "spades", "clubs", "diamonds"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        textviewrounds = findViewById(R.id.textviewforrounds);
        textviewforrounds = findViewById(R.id.textviewforscores);
        cardimageforplayer1 = findViewById(R.id.imgCard1);
        cardimageforplayer2 = findViewById(R.id.imgCard2);
        cardimagefordeck = findViewById(R.id.imgDeck);
        buttonforcarddistribute = findViewById(R.id.buttonforcarddistribute);
        buttonfornextround = findViewById(R.id.buttonfornextround);


        cardimageforplayer1.setVisibility(View.GONE);
        cardimageforplayer2.setVisibility(View.GONE);
        textviewrounds.setVisibility(View.GONE);
        textviewforrounds.setVisibility(View.GONE);
        buttonfornextround.setVisibility(View.GONE);
        cardimagefordeck.setVisibility(View.VISIBLE);
        buttonfornextround.setEnabled(false);

        buttonforcarddistribute.setOnClickListener(v -> startShuffle());
        buttonfornextround.setOnClickListener(v -> playRound());

        updateScoreRound();
    }

    private void startShuffle() {
        Animation shuffleAnim = AnimationUtils.loadAnimation(this, R.anim.shuffle_anim);
        cardimagefordeck.startAnimation(shuffleAnim);

        shuffleAnim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                buttonforcarddistribute.setEnabled(false);
                buttonfornextround.setEnabled(false);
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                setupGame();
                cardimageforplayer1.setVisibility(View.VISIBLE);
                cardimageforplayer2.setVisibility(View.VISIBLE);
                textviewrounds.setVisibility(View.VISIBLE);
                textviewforrounds.setVisibility(View.VISIBLE);
                buttonfornextround.setVisibility(View.VISIBLE);
                buttonfornextround.setEnabled(true);
                cardimagefordeck.clearAnimation();
                cardimagefordeck.setVisibility(View.GONE);
                buttonforcarddistribute.setVisibility(View.GONE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }
        });
    }

    private void setupGame() {
        middledeck = new ArrayList<>();
        for (String suit : suits) {
            for (int val = 2; val <= 14; val++) {
                middledeck.add(new TheCard(suit, val));
            }
        }

        Collections.shuffle(middledeck);

        carddeck1 = new ArrayList<>(middledeck.subList(0, 26));
        carddeck2 = new ArrayList<>(middledeck.subList(26, 52));

        player1Score = 0;
        player2Score = 0;
        round = 1;

        updateScoreRound();

        cardimageforplayer1.setImageResource(R.drawable.closed_deck_image);
        cardimageforplayer2.setImageResource(R.drawable.closed_deck_image);
    }

    private void playRound() {
        if (round > 26) {
            Intent intent = new Intent(this, ResultActivity.class);
            intent.putExtra("score1", player1Score);
            intent.putExtra("score2", player2Score);
            startActivity(intent);
            finish();
            return;
        }

        TheCard card1 = carddeck1.remove(0);
        TheCard card2 = carddeck2.remove(0);

        int resId1 = getResources().getIdentifier(card1.getNameofcard(), "drawable", getPackageName());
        int resId2 = getResources().getIdentifier(card2.getNameofcard(), "drawable", getPackageName());

        if (resId1 == 0) resId1 = R.drawable.closed_deck_image;
        if (resId2 == 0) resId2 = R.drawable.closed_deck_image;

        final int finalResId1 = resId1;
        final int finalResId2 = resId2;

        Animation flipOut = AnimationUtils.loadAnimation(this, R.anim.flip_out);
        Animation flipIn = AnimationUtils.loadAnimation(this, R.anim.flip_in);

        cardimageforplayer1.startAnimation(flipOut);
        cardimageforplayer2.startAnimation(flipOut);

        flipOut.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {}

            @Override
            public void onAnimationEnd(Animation animation) {
                cardimageforplayer1.setImageResource(finalResId1);
                cardimageforplayer2.setImageResource(finalResId2);

                cardimageforplayer1.startAnimation(flipIn);
                cardimageforplayer2.startAnimation(flipIn);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {}
        });

        if (card1.getCardValue() > card2.getCardValue()) {
            player1Score++;
        } else if (card2.getCardValue() > card1.getCardValue()) {
            player2Score++;
        }

        updateScoreRound();

        round++;
        if (round > 26) {
            buttonfornextround.setText("Display result:");
            buttonfornextround.setOnClickListener(v -> {
                Intent intent = new Intent(GameActivity.this, ResultActivity.class);
                intent.putExtra("score1", player1Score);
                intent.putExtra("score2", player2Score);
                startActivity(intent);
                finish();
            });
        }
    }

    private void updateScoreRound() {
        textviewrounds.setText("Game round:" + round);
        textviewforrounds.setText("Player 1 score: " + player1Score + "  |  Player 2 score: " + player2Score);
    }
}
