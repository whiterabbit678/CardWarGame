package com.example.cardgame;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        TextView tvResult = findViewById(R.id.textviewofresults);
        Button btnPlayAgain = findViewById(R.id.buttonforplayagain);
        Intent intent = getIntent();
        int score1 = intent.getIntExtra("score1", 0);
        int score2 = intent.getIntExtra("score2", 0);

        String resultText;
        if (score1 > score2) {
            resultText = "Player 1 is the Winner!\n" + score1 + " to " + score2;
        } else if (score2 > score1) {
            resultText = "Player 2 is the Winner!\n" + score2 + " to " + score1;
        } else {
            resultText = "It's a tie!!!!\n" + score1 + " to " + score2;
        }

        tvResult.setText(resultText);

        btnPlayAgain.setOnClickListener(v -> {
            Intent i = new Intent(ResultActivity.this, GameActivity.class);
            startActivity(i);
            finish();  // Close ResultActivity after starting GameActivity
        });
    }
}
