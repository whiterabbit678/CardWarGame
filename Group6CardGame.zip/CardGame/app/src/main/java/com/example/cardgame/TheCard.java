package com.example.cardgame;

public class TheCard {
    private final String cardname;
    private final int valueofcard;
    private final String nameofcard;

    public TheCard(String cardname, int valueofcard) {
        this.cardname = cardname;
        this.valueofcard = valueofcard;
        this.nameofcard = cardname + "_of_" + valueofcard;
    }

    public int getCardValue() {
        return valueofcard;
    }

    public String getNameofcard() {
        return nameofcard;
    }
}
